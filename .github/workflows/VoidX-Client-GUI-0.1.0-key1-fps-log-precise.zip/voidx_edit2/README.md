# VoidX Client — FPS Diagnostics

Minecraft 1.21.11 Fabric client-side utility.

## Added
- FPS counter at the top-right with a black background.
- `L` opens/closes the FPS diagnostics log.
- Session FPS history is kept while Minecraft is running.
- Detects sharp FPS drops and records the measured drop.
- Records a **possible** cause using enabled VoidX performance systems (chunk loading, entity rendering, particles, or general render/frametime load).
- The log remains on screen until closed and keeps recent entries.
- `ESC` also closes the log.

The cause is intentionally labeled as "possible": a client HUD cannot know the exact internal cause of every frame-time spike without a full profiler.
