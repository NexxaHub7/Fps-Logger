package com.luiscript.boxpvp;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class BoxConfig {
    public static boolean hud = true;
    public static boolean cps = true;
    public static boolean fps = true;
    public static boolean ping = true;
    public static boolean armor = true;
    public static boolean boost = true;
    public static boolean noParticles = true;
    public static boolean fireworkFix = true;
    public static boolean bgThrottle = true;
    public static boolean fpsStabilizer = true;
    public static boolean entityDistance = true;
    public static boolean particleManager = true;
    public static boolean progressiveChunks = true;

    // VoidX GUI visual settings.
    public static int guiScale = 100;
    public static boolean guiBorder = true;
    public static boolean guiRainbow = false;
    public static boolean guiGlow = true;
    public static int guiOpacity = 94;
    public static boolean hudRainbow = false;

    // HUD editor settings.
    public static int hudX = 8;
    public static int hudY = 8;
    public static int hudScale = 100;

    private BoxConfig() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("boxpvp_utils.properties");
    }

    private static boolean get(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static int getInt(Properties p, String key, int def, int min, int max) {
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(p.getProperty(key, String.valueOf(def)))));
        } catch (NumberFormatException ignored) {
            return def;
        }
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        hud = get(p, "hud", hud);
        cps = get(p, "cps", cps);
        fps = get(p, "fps", fps);
        ping = get(p, "ping", ping);
        armor = get(p, "armor", armor);
        boost = get(p, "boost", boost);
        noParticles = get(p, "noParticles", noParticles);
        fireworkFix = get(p, "fireworkFix", fireworkFix);
        bgThrottle = get(p, "bgThrottle", bgThrottle);
        fpsStabilizer = get(p, "fpsStabilizer", fpsStabilizer);
        entityDistance = get(p, "entityDistance", entityDistance);
        particleManager = get(p, "particleManager", particleManager);
        progressiveChunks = get(p, "progressiveChunks", progressiveChunks);
        guiScale = getInt(p, "guiScale", guiScale, 85, 115);
        guiBorder = get(p, "guiBorder", guiBorder);
        guiRainbow = get(p, "guiRainbow", guiRainbow);
        guiGlow = get(p, "guiGlow", guiGlow);
        guiOpacity = getInt(p, "guiOpacity", guiOpacity, 55, 100);
        hudRainbow = get(p, "hudRainbow", hudRainbow);
        hudX = getInt(p, "hudX", hudX, -2000, 2000);
        hudY = getInt(p, "hudY", hudY, -2000, 2000);
        hudScale = getInt(p, "hudScale", hudScale, 70, 140);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hud", String.valueOf(hud));
        p.setProperty("cps", String.valueOf(cps));
        p.setProperty("fps", String.valueOf(fps));
        p.setProperty("ping", String.valueOf(ping));
        p.setProperty("armor", String.valueOf(armor));
        p.setProperty("boost", String.valueOf(boost));
        p.setProperty("noParticles", String.valueOf(noParticles));
        p.setProperty("fireworkFix", String.valueOf(fireworkFix));
        p.setProperty("bgThrottle", String.valueOf(bgThrottle));
        p.setProperty("fpsStabilizer", String.valueOf(fpsStabilizer));
        p.setProperty("entityDistance", String.valueOf(entityDistance));
        p.setProperty("particleManager", String.valueOf(particleManager));
        p.setProperty("progressiveChunks", String.valueOf(progressiveChunks));
        p.setProperty("guiScale", String.valueOf(guiScale));
        p.setProperty("guiBorder", String.valueOf(guiBorder));
        p.setProperty("guiRainbow", String.valueOf(guiRainbow));
        p.setProperty("guiGlow", String.valueOf(guiGlow));
        p.setProperty("guiOpacity", String.valueOf(guiOpacity));
        p.setProperty("hudRainbow", String.valueOf(hudRainbow));
        p.setProperty("hudX", String.valueOf(hudX));
        p.setProperty("hudY", String.valueOf(hudY));
        p.setProperty("hudScale", String.valueOf(hudScale));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "VoidX Client");
        } catch (IOException ignored) {
        }
    }
}
