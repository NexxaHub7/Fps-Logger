package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;

import java.lang.management.ManagementFactory;
import java.lang.management.GarbageCollectorMXBean;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.List;

/**
 * Session-only FPS diagnostics.
 *
 * The log does not pretend to know the exact cause of a frame spike. Instead it
 * records measurable signals at the same moment: heap usage, GC activity,
 * loaded client chunks and entity count. A cause is only reported as detected
 * when the corresponding signal changes at the same time as the FPS drop.
 */
public final class LagLog {
    private static final int MAX_LINES = 100;
    private static final int HISTORY_SIZE = 16;
    private static final Deque<String> LINES = new ArrayDeque<>();
    private static final Deque<Integer> FPS_HISTORY = new ArrayDeque<>();

    private static long lastSample;
    private static long lastDropLog;
    private static long lastGcCollections;
    private static long lastGcTime;
    private static int lastFps = -1;
    private static int lastChunks = -1;
    private static int lastEntities = -1;
    private static long lastUsedMemory = -1;
    private static double average;
    private static boolean started;

    private LagLog() {}

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.screen instanceof LagLogScreen) return;

        long now = System.currentTimeMillis();
        if (now - lastSample < 250) return;
        lastSample = now;

        int fps = Math.max(0, mc.getFps());
        if (fps <= 0) return;

        long usedMemory = usedMemory();
        int chunks = loadedChunks(mc);
        int entities = entityCount(mc);
        long gcCollections = gcCollections();
        long gcTime = gcTime();

        FPS_HISTORY.addLast(fps);
        while (FPS_HISTORY.size() > HISTORY_SIZE) FPS_HISTORY.removeFirst();
        average = averageFpsFromHistory();

        if (!started) {
            started = true;
            lastFps = fps;
            lastChunks = chunks;
            lastEntities = entities;
            lastUsedMemory = usedMemory;
            lastGcCollections = gcCollections;
            lastGcTime = gcTime;
            add("[LOG] Diagnóstico iniciado | FPS " + fps + " | chunks " + chunks + " | entidades " + entities + " | RAM " + memoryText(usedMemory));
            return;
        }

        int drop = lastFps - fps;
        boolean sharpDrop = drop >= 8 && fps < average * 0.80;
        boolean severeDrop = fps <= 20 && drop >= 4;

        if ((sharpDrop || severeDrop) && now - lastDropLog >= 750) {
            lastDropLog = now;
            addDrop(mc, fps, drop, usedMemory, chunks, entities, gcCollections, gcTime);
        }

        lastFps = fps;
        lastChunks = chunks;
        lastEntities = entities;
        lastUsedMemory = usedMemory;
        lastGcCollections = gcCollections;
        lastGcTime = gcTime;
    }

    private static void addDrop(Minecraft mc, int fps, int drop, long usedMemory, int chunks,
                                int entities, long gcCollections, long gcTime) {
        String time = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
        StringBuilder line = new StringBuilder();
        line.append("[").append(time).append("] [DROP] ")
                .append(lastFps).append(" -> ").append(fps)
                .append(" FPS (-").append(drop).append(")")
                .append(" | frame ").append(frameTime(fps)).append(" ms")
                .append(" | avg ").append((int) Math.round(average));

        // Only call something a detected cause when a measurable signal agrees
        // with the FPS drop. Otherwise it stays explicitly unknown.
        boolean gcSpike = gcCollections > lastGcCollections || gcTime > lastGcTime;
        boolean chunkSpike = lastChunks >= 0 && chunks - lastChunks >= 2;
        boolean entitySpike = lastEntities >= 0 && entities - lastEntities >= 10;
        boolean memoryPressure = usedMemory > 0 && usedMemory > maxMemory() * 0.88 && usedMemory > lastUsedMemory;

        line.append(" | señales: ");
        boolean any = false;

        if (gcSpike) {
            line.append("GC");
            any = true;
        }
        if (memoryPressure) {
            if (any) line.append(", ");
            line.append("RAM alta");
            any = true;
        }
        if (chunkSpike) {
            if (any) line.append(", ");
            line.append("+" ).append(chunks - lastChunks).append(" chunks");
            any = true;
        }
        if (entitySpike) {
            if (any) line.append(", ");
            line.append("+" ).append(entities - lastEntities).append(" entidades");
            any = true;
        }
        if (!any) line.append("sin señal concluyente");

        line.append(" | RAM ").append(memoryText(usedMemory))
                .append(" | chunks ").append(chunks)
                .append(" | entidades ").append(entities)
                .append(" | GC ").append(gcCollections);

        add(line.toString());
    }

    private static int loadedChunks(Minecraft mc) {
        try {
            return mc.level.getChunkSource().getLoadedChunksCount();
        } catch (Throwable ignored) {
            try {
                return mc.level.getChunkSource().getLoadedChunkCount();
            } catch (Throwable ignoredAgain) {
                return -1;
            }
        }
    }

    private static int entityCount(Minecraft mc) {
        try {
            return mc.level.getEntityCount();
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private static long usedMemory() {
        Runtime r = Runtime.getRuntime();
        return r.totalMemory() - r.freeMemory();
    }

    private static long maxMemory() {
        return Runtime.getRuntime().maxMemory();
    }

    private static long gcCollections() {
        long total = 0;
        List<GarbageCollectorMXBean> beans = ManagementFactory.getGarbageCollectorMXBeans();
        for (GarbageCollectorMXBean bean : beans) {
            long count = bean.getCollectionCount();
            if (count >= 0) total += count;
        }
        return total;
    }

    private static long gcTime() {
        long total = 0;
        List<GarbageCollectorMXBean> beans = ManagementFactory.getGarbageCollectorMXBeans();
        for (GarbageCollectorMXBean bean : beans) {
            long time = bean.getCollectionTime();
            if (time >= 0) total += time;
        }
        return total;
    }

    private static double averageFpsFromHistory() {
        if (FPS_HISTORY.isEmpty()) return 0;
        long sum = 0;
        for (int fps : FPS_HISTORY) sum += fps;
        return (double) sum / FPS_HISTORY.size();
    }

    private static String memoryText(long bytes) {
        if (bytes < 0) return "?";
        return String.format("%.0f/%.0f MB", bytes / 1048576.0, maxMemory() / 1048576.0);
    }

    private static String frameTime(int fps) {
        if (fps <= 0) return "?";
        return String.format("%.1f", 1000.0 / fps);
    }

    public static void add(String line) {
        if (LINES.size() >= MAX_LINES) LINES.removeFirst();
        LINES.addLast(line);
    }

    public static String[] lines() {
        return LINES.toArray(new String[0]);
    }

    public static int currentFps() {
        return Math.max(0, Minecraft.getInstance().getFps());
    }

    public static int averageFps() {
        return (int) Math.round(average);
    }

    public static void clear() {
        LINES.clear();
        FPS_HISTORY.clear();
        lastSample = 0;
        lastDropLog = 0;
        lastFps = -1;
        lastChunks = -1;
        lastEntities = -1;
        lastUsedMemory = -1;
        lastGcCollections = 0;
        lastGcTime = 0;
        average = 0;
        started = false;
        add("[LOG] Historial limpiado. Esperando nuevas mediciones...");
    }
}
