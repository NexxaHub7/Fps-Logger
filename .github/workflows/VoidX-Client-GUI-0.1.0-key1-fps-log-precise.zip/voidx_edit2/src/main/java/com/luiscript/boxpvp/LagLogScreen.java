package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class LagLogScreen extends Screen {
    public LagLogScreen() {
        super(Component.literal("VoidX FPS Log"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        Minecraft mc = Minecraft.getInstance();

        // Transparent overlay: the world remains visible behind the diagnostics.
        int panelH = Math.min(190, Math.max(110, height / 3));
        int top = height - panelH;
        g.fill(0, top, width, height, 0xE908090C);
        g.fill(0, top, width, top + 1, 0xFF00CFFF);
        g.fill(0, top + 1, 3, height, 0xFF00CFFF);

        g.drawString(font, Component.literal("VOIDX • FPS DIAGNOSTICS"), 12, top + 10, 0xFF7DEBFF);
        g.drawString(font, Component.literal("L = cerrar   ESC = cerrar   historial de esta sesión"), 12, top + 23, 0xFF8D919A);

        String[] lines = LagLog.lines();
        int lineY = height - 12;
        int maxLines = Math.max(1, (panelH - 40) / 10);
        int start = Math.max(0, lines.length - maxLines);
        for (int i = lines.length - 1; i >= start; i--) {
            String line = lines[i];
            if (line.length() > 130) line = line.substring(0, 127) + "...";
            g.drawString(font, Component.literal(line), 12, lineY, line.startsWith("[LOG]") ? 0xFFB8BEC8 : 0xFFE5E7EB);
            lineY -= 10;
        }

        int fps = mc.getFps();
        String stats = "FPS " + fps + "  |  avg " + LagLog.averageFps() + "  |  frame " + (fps > 0 ? String.format("%.1f", 1000.0 / fps) : "?") + " ms";
        int sw = font.width(stats);
        g.fill(width - sw - 18, 7, width - 7, 25, 0xE9000000);
        g.drawString(font, Component.literal(stats), width - sw - 12, 12, fps < 30 ? 0xFFFF6666 : 0xFF7DEBFF);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (event.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_L || event.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }
}
